import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Search, BookOpen, Heart, Share2, Moon, Sun, Star, Facebook, Users } from 'lucide-react'
import islamicPattern1 from './assets/islamic-pattern-1.jpg'
import islamicPattern2 from './assets/islamic-pattern-2.jpg'
import mosqueSilhouette from './assets/mosque-silhouette.jpg'
import './App.css'

function App() {
  const [darkMode, setDarkMode] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [activeSection, setActiveSection] = useState('quran')
  const [favorites, setFavorites] = useState(new Set())

  // بيانات الأدعية القرآنية
  const quranDuas = [
    {
      id: 1,
      title: 'دعاء سيدنا إبراهيم',
      arabic: 'رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي ۚ رَبَّنَا وَتَقَبَّلْ دُعَاءِ',
      reference: 'سورة إبراهيم - 40',
      context: 'دعاء سيدنا إبراهيم عليه السلام، يُقال بعد الصلاة وعند الدعاء للذرية',
      benefits: 'الدعاء للذرية - الاستعانة بالله - طلب القبول من الله',
      occasion: 'بعد الصلاة - عند الدعاء للأولاد'
    },
    {
      id: 2,
      title: 'دعاء الثبات على الدين',
      arabic: 'رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ۚ إِنَّكَ أَنتَ الْوَهَّابُ',
      reference: 'سورة آل عمران - 8',
      context: 'دعاء جامع للاستعاذة من زيغ القلوب وطلب الرحمة والهداية',
      benefits: 'الثبات على الدين - طلب الرحمة - الاستعاذة من الضلال',
      occasion: 'عند الخوف من الفتن - في أوقات الضعف الإيماني'
    }
  ]

  // بيانات الأدعية النبوية
  const propheticDuas = [
    {
      id: 3,
      title: 'دعاء الصباح المبارك',
      arabic: 'اللَّهُمَّ أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
      reference: 'رواه الترمذي',
      context: 'دعاء جامع للاعتراف بوحدانية الله في جميع أحوال العبد من صباح ومساء وحياة وموت ومرض',
      benefits: 'الحماية بالأسرة - الاعتراف بوحدانية الله - طلب الحفظ والرعاية',
      occasion: 'عند الصباح - في أوقات الخوف والقلق'
    },
    {
      id: 4,
      title: 'دعاء الثبات على الحق',
      arabic: 'اللَّهُمَّ يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ',
      reference: 'رواه الترمذي',
      context: 'دعاء سيدنا إبراهيم عليه السلام، يُقال بعد الصلاة وعند الدعاء للذرية',
      benefits: 'الثبات على الدين - طلب الهداية - الاستعاذة من تقلب القلوب',
      occasion: 'عند الكروب - في أوقات الفتن والمحن'
    }
  ]

  // بيانات الأذكار اليومية
  const dailyAdhkar = [
    {
      id: 5,
      title: 'سبحان الله وبحمده',
      arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
      reference: 'متفق عليه',
      context: 'ذكر عظيم يُقال في جميع الأوقات',
      benefits: 'تنزيه الله - الحمد والثناء - تطهير القلب',
      occasion: 'في جميع الأوقات - بعد الصلاة'
    }
  ]

  const toggleFavorite = (id) => {
    const newFavorites = new Set(favorites)
    if (newFavorites.has(id)) {
      newFavorites.delete(id)
    } else {
      newFavorites.add(id)
    }
    setFavorites(newFavorites)
  }

  const getCurrentData = () => {
    switch (activeSection) {
      case 'quran': return quranDuas
      case 'prophetic': return propheticDuas
      case 'daily': return dailyAdhkar
      default: return []
    }
  }

  const filteredData = getCurrentData().filter(item =>
    item.title.includes(searchTerm) || item.arabic.includes(searchTerm)
  )

  const handleFacebookClick = () => {
    window.open('https://www.facebook.com/your-page', '_blank')
  }

  const handleGroupClick = () => {
    window.open('https://www.facebook.com/groups/your-group', '_blank')
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark' : ''}`}>
      {/* Background Pattern */}
      <div 
        className="fixed inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `url(${islamicPattern1})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />

      {/* Header with Islamic Background */}
      <header 
        className="relative bg-gradient-to-r from-emerald-600 to-teal-600 dark:from-emerald-800 dark:to-teal-800 text-white shadow-lg overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(rgba(16, 185, 129, 0.9), rgba(20, 184, 166, 0.9)), url(${mosqueSilhouette})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto px-4 py-8 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <BookOpen className="h-10 w-10" />
              <div>
                <h1 className="text-3xl font-bold mb-2">احفظ الله يحفظك</h1>
                <p className="text-emerald-100 text-lg">موسوعة الأدعية والأذكار من القرآن والسنة</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              {/* Facebook Page Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleFacebookClick}
                className="text-white hover:bg-white/20 flex items-center space-x-2 rtl:space-x-reverse"
              >
                <Facebook className="h-5 w-5" />
                <span>صفحتنا</span>
              </Button>
              
              {/* Facebook Group Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleGroupClick}
                className="text-white hover:bg-white/20 flex items-center space-x-2 rtl:space-x-reverse"
              >
                <Users className="h-5 w-5" />
                <span>مجموعتنا</span>
              </Button>

              {/* Dark Mode Toggle */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setDarkMode(!darkMode)}
                className="text-white hover:bg-white/20"
              >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm shadow-md border-b relative z-20">
        <div className="container mx-auto px-4">
          <div className="flex space-x-8 rtl:space-x-reverse">
            {[
              { id: 'quran', label: 'أدعية قرآنية', icon: BookOpen },
              { id: 'prophetic', label: 'أدعية نبوية', icon: Heart },
              { id: 'daily', label: 'أذكار يومية', icon: Star }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={`flex items-center space-x-2 rtl:space-x-reverse py-4 px-2 border-b-2 transition-colors ${
                  activeSection === id
                    ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                    : 'border-transparent text-gray-600 dark:text-gray-400 hover:text-emerald-600 dark:hover:text-emerald-400'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Search Section with Pattern Background */}
      <div 
        className="relative py-8"
        style={{
          backgroundImage: `linear-gradient(rgba(249, 250, 251, 0.95), rgba(249, 250, 251, 0.95)), url(${islamicPattern2})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto px-4">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              type="text"
              placeholder="ابحث في الأدعية والأذكار..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10 text-right bg-white/90 backdrop-blur-sm"
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 relative z-10">
        <div className="grid gap-6">
          {filteredData.map((item) => (
            <Card key={item.id} className="hover:shadow-lg transition-all duration-300 bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-emerald-100 dark:border-emerald-800">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-right text-emerald-700 dark:text-emerald-400 mb-2">
                      {item.title}
                    </CardTitle>
                    <CardDescription className="text-right">
                      <Badge variant="secondary" className="mb-2 bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">
                        {item.reference}
                      </Badge>
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => toggleFavorite(item.id)}
                      className={favorites.has(item.id) ? 'text-red-500' : 'text-gray-400'}
                    >
                      <Heart className={`h-5 w-5 ${favorites.has(item.id) ? 'fill-current' : ''}`} />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-emerald-600">
                      <Share2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20 p-6 rounded-lg border border-emerald-100 dark:border-emerald-800">
                    <p className="text-xl leading-relaxed text-right font-arabic text-emerald-900 dark:text-emerald-100">
                      {item.arabic}
                    </p>
                  </div>
                  
                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                      <h4 className="font-semibold text-emerald-700 dark:text-emerald-400 mb-2">السياق:</h4>
                      <p className="text-gray-600 dark:text-gray-400 text-right">{item.context}</p>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                      <h4 className="font-semibold text-emerald-700 dark:text-emerald-400 mb-2">الفوائد:</h4>
                      <p className="text-gray-600 dark:text-gray-400 text-right">{item.benefits}</p>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                      <h4 className="font-semibold text-emerald-700 dark:text-emerald-400 mb-2">المناسبة:</h4>
                      <p className="text-gray-600 dark:text-gray-400 text-right">{item.occasion}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredData.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">
              لا توجد نتائج
            </h3>
            <p className="text-gray-500 dark:text-gray-500">
              جرب البحث بكلمات مختلفة أو تصفح الأقسام المختلفة
            </p>
          </div>
        )}
      </main>

      {/* Footer with Islamic Pattern */}
      <footer 
        className="relative bg-gray-900 text-white py-12 mt-12 overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(rgba(17, 24, 39, 0.95), rgba(17, 24, 39, 0.95)), url(${islamicPattern1})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse mb-6">
            <BookOpen className="h-8 w-8" />
            <span className="text-2xl font-semibold">احفظ الله يحفظك</span>
          </div>
          <p className="text-gray-300 mb-6 text-lg">
            موسوعة شاملة للأدعية القرآنية والنبوية والأذكار اليومية
          </p>
          <div className="flex justify-center space-x-6 rtl:space-x-reverse">
            <Button 
              variant="ghost" 
              size="lg" 
              onClick={handleFacebookClick}
              className="text-gray-300 hover:text-white hover:bg-white/10 flex items-center space-x-2 rtl:space-x-reverse"
            >
              <Facebook className="h-6 w-6" />
              <span>صفحتنا على فيسبوك</span>
            </Button>
            <Button 
              variant="ghost" 
              size="lg" 
              onClick={handleGroupClick}
              className="text-gray-300 hover:text-white hover:bg-white/10 flex items-center space-x-2 rtl:space-x-reverse"
            >
              <Users className="h-6 w-6" />
              <span>انضم لمجموعتنا</span>
            </Button>
          </div>
          <div className="mt-8 pt-6 border-t border-gray-700">
            <p className="text-gray-400 text-sm">
              جميع الحقوق محفوظة © 2024 - احفظ الله يحفظك
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

